document.addEventListener('DOMContentLoaded', function () {
  let imageIndex = 0;
  const images = [
    'https://plus.unsplash.com/premium_photo-1677993185892-f7823f314c4c?q=80&w=1887&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    'https://images.unsplash.com/photo-1592853625597-7d17be820d0c?q=80&w=2075&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    'https://plus.unsplash.com/premium_photo-1683134242640-fe6baaf4d5fc?q=80&w=1895&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'
  ];

  function changeImage() {
    const featureSection = document.getElementById('imageSlider');
    featureSection.style.backgroundImage = `url('${images[imageIndex]}')`;

    // Increment image index and loop back to the first image
    imageIndex = (imageIndex + 1) % images.length;
  }

  // Listen for scroll events and trigger image change
  document.addEventListener('scroll', changeImage);
});
